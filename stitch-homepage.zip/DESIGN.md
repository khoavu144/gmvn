# Design System Strategy: Kinetic Editorial

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Kinetic Gallery."** We are moving away from the standard "fitness app" aesthetic of neon accents and heavy borders. Instead, we are leaning into a high-end editorial experience that mirrors the precision and discipline of elite performance. 

This system leverages **Lexend’s** geometric clarity to create a sense of focused energy. By utilizing intentional asymmetry, high-contrast typography scales, and tonal depth, we create a layout that feels curated rather than templated. We treat the user interface as a breathable, premium environment where every element has the space to "perform."

---

## 2. Color & Surface Architecture
We use a monochrome-first palette to emphasize content and athleticism. Our color strategy relies on the subtle interplay of light and shadow rather than explicit lines.

- **Primary (`#000000`) & On-Primary (`#E5E2E1`):** Used for maximum impact and high-performance "call-to-action" moments.
- **Surface & Background:** The page begins at `background` (`#F9F9F9`). We use the `surface-container` tiers to build depth.
- **The "No-Line" Rule:** 1px solid borders are strictly prohibited for sectioning. Contrast must be achieved through background shifts. For example, a "Top Coaches" section should sit on `surface-container-low`, while the individual coach cards utilize `surface-container-lowest` (pure white) to appear physically elevated.
- **The "Glass & Gradient" Rule:** To evoke a "kinetic" feel, floating navigation or overlay elements should use a semi-transparent `surface` color with a `backdrop-blur` of 12px-20px. 
- **Signature Textures:** For high-impact hero sections, use a subtle radial gradient transitioning from `primary` (#000000) to `primary-container` (#3C3B3B) to provide a "soulful" depth that flat black cannot achieve.

---

## 3. Typography
**Lexend** is our voice. It is engineered for reading proficiency and provides a modern, high-tech edge.

- **Display Scales (lg/md/sm):** Reserved for "Hook" statements and section headers. Use `display-lg` (3.5rem) with tight tracking (-0.02em) to create a bold, authoritative editorial look.
- **Headline & Title:** Used for card titles and sub-headers. These should always be `on-surface` (#1A1C1C) to maintain a crisp, readable hierarchy.
- **Body & Labels:** `body-md` (0.875rem) is our workhorse. Use `secondary-text` (#666666) for body copy to allow the primary headlines to remain the focal point.
- **Intentional Contrast:** Pair a `display-lg` headline with a `label-md` uppercase sub-header to create a "Big/Small" typographic tension characteristic of premium lifestyle magazines.

---

## 4. Elevation & Depth
In this system, depth is a feeling, not a structure. We utilize **Tonal Layering** to guide the eye.

- **The Layering Principle:** Avoid shadows where background color shifts can do the work. A `surface-container-lowest` card on a `surface-container-low` background creates a "Soft Lift."
- **Ambient Shadows:** When a card requires a floating effect (e.g., featured athlete), use a shadow with a blur of 24px-32px at 4% opacity. The shadow color must be a tint of `on-surface` (#1A1C1C) to mimic natural light.
- **The "Ghost Border" Fallback:** If a container requires definition against a similar background, use a 1px "Ghost Border" using `outline-variant` at 15% opacity. Never use a 100% opaque border.
- **Glassmorphism:** For action overlays (like "Quick Book"), use `surface` at 80% opacity with a blur effect to ensure the UI feels integrated with the imagery behind it.

---

## 5. Components

### Buttons
- **Primary:** `primary` background, `on-primary` text. Radius: `8px`. No border. High-contrast.
- **Secondary:** `outline` border (Ghost Border style), `primary` text. Transparent background.
- **Interaction:** On hover, primary buttons should shift to `primary-fixed-dim` with a subtle `2.5` (0.85rem) scale increase to signify kinetic energy.

### Cards & Lists
- **The "No-Divider" Rule:** Never use horizontal lines to separate list items. Use vertical white space (`spacing-4` or `spacing-6`) and `surface-container` background shifts.
- **Coach Cards:** Use `radius-lg` (12px) for image containers. Text should be inset using `spacing-4` (1.4rem) to ensure an editorial feel.

### Chips (Specialized for GymCenter)
- **Tagging:** Use `surface-container-high` for background with `label-md` text. Used for "Yoga," "HIIT," or "Strength" tags.
- **Active State:** Use `primary` background with `on-primary` text.

### Input Fields
- **Minimalist State:** No background; only an `outline-variant` bottom border (Ghost style). 
- **Focus State:** Transitions to a `primary` 2px bottom border. Text remains `body-md`.

---

## 6. Do’s and Don’ts

### Do:
- **Use Asymmetry:** Place text off-center or allow images to "break" the container edges to create movement.
- **Embrace White Space:** Use the `spacing-16` (5.5rem) or `spacing-20` (7rem) scales between major sections to let the design breathe.
- **Typography as Art:** Treat large `display` type as a visual element, not just information.

### Don't:
- **Don't use 100% Black Borders:** This kills the premium "editorial" feel and makes the UI look like a wireframe.
- **Don't Over-Shadow:** If every card has a shadow, nothing feels elevated. Use shadows only for "High" importance elements.
- **Don't Use Generic Icons:** Ensure all iconography is thin-stroke (1px to 1.5px) to match the Lexend typeface weight.
- **Don't Crowd the Content:** If a section feels "busy," increase the spacing scale by one tier (e.g., move from `spacing-8` to `spacing-10`).