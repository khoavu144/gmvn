import { Request, Response } from 'express';
import { subscriptionService } from '../services/subscriptionService';

export const createCheckout = async (req: Request, res: Response) => {
    try {
        const userId = req.user!.user_id;
        const { program_id } = req.body;
        if (!program_id) return res.status(400).json({ error: 'program_id is required' });

        const session = await subscriptionService.createCheckoutSession(userId, program_id);
        res.json({ success: true, ...session });
    } catch (err: any) {
        res.status(400).json({ error: err.message });
    }
};

export const confirmPayment = async (req: Request, res: Response) => {
    try {
        const userId = req.user!.user_id;
        const { stripe_payment_intent_id } = req.body;
        if (!stripe_payment_intent_id) {
            return res.status(400).json({ error: 'stripe_payment_intent_id is required' });
        }

        const subscription = await subscriptionService.confirmPayment(userId, stripe_payment_intent_id);
        res.json({ success: true, subscription });
    } catch (err: any) {
        res.status(400).json({ error: err.message });
    }
};

export const getMySubscriptions = async (req: Request, res: Response) => {
    try {
        const userId = req.user!.user_id;
        const subscriptions = await subscriptionService.getUserSubscriptions(userId);
        res.json({ success: true, subscriptions });
    } catch (err: any) {
        res.status(400).json({ error: err.message });
    }
};

export const cancelSubscription = async (req: Request, res: Response) => {
    try {
        const userId = req.user!.user_id;
        const { id } = req.params;
        const subscription = await subscriptionService.cancelSubscription(userId, String(id));
        res.json({ success: true, subscription });
    } catch (err: any) {
        res.status(400).json({ error: err.message });
    }
};

export const stripeWebhook = async (req: Request, res: Response) => {
    // Stripe sends raw body - handle webhook events
    const sig = req.headers['stripe-signature'];
    // In production, verify webhook signature here
    const event = req.body;

    try {
        switch (event.type) {
            case 'payment_intent.succeeded':
                // Could auto-confirm subscriptions here
                console.log('✅ Stripe PaymentIntent succeeded:', event.data.object.id);
                break;
            case 'invoice.payment_failed':
                console.log('❌ Stripe Invoice payment failed');
                break;
            default:
                console.log(`Unhandled Stripe event: ${event.type}`);
        }
        res.json({ received: true });
    } catch (err: any) {
        res.status(400).json({ error: err.message });
    }
};
