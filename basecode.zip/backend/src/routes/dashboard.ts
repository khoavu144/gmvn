import { Router } from 'express';
import { authenticate, trainerOnly } from '../middleware/auth';
import { getOverview, getClients, getPayments } from '../controllers/dashboardController';

const router = Router();

router.get('/overview', authenticate as any, trainerOnly as any, getOverview as any);
router.get('/clients', authenticate as any, trainerOnly as any, getClients as any);
router.get('/payments', authenticate as any, trainerOnly as any, getPayments as any);

export default router;
