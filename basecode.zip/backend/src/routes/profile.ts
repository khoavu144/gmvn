import { Router } from 'express';
import { authenticate, trainerOnly } from '../middleware/auth';
import {
    getPublicProfile,
    getFullPublicProfile,
    getProfileBySlug,
    getMyProfile,
    updateMyProfile,
    // Experience
    getExperience,
    addExperience,
    updateExperience,
    deleteExperience,
    // Gallery
    getGallery,
    addGalleryImage,
    updateGalleryImage,
    deleteGalleryImage,
    // FAQ
    getFAQ,
    addFAQ,
    updateFAQ,
    deleteFAQ,
} from '../controllers/profileController';

const router = Router();
const auth = authenticate as any;
const trainerAuth = [authenticate as any, trainerOnly as any];

// ── PUBLIC ────────────────────────────────────────────────────────────────────
router.get('/slug/:slug', getProfileBySlug as any);
router.get('/trainer/:trainerId', getPublicProfile as any);
router.get('/trainer/:trainerId/full', getFullPublicProfile as any);
router.get('/trainer/:trainerId/experience', getExperience as any);
router.get('/trainer/:trainerId/gallery', getGallery as any);
router.get('/trainer/:trainerId/faq', getFAQ as any);

// ── TRAINER PROTECTED ─────────────────────────────────────────────────────────
// Core profile
router.get('/me', auth, getMyProfile as any);
router.put('/me', ...trainerAuth, updateMyProfile as any);

// Experience CRUD
router.post('/me/experience', ...trainerAuth, addExperience as any);
router.put('/me/experience/:id', ...trainerAuth, updateExperience as any);
router.delete('/me/experience/:id', ...trainerAuth, deleteExperience as any);

// Gallery CRUD
router.post('/me/gallery', ...trainerAuth, addGalleryImage as any);
router.put('/me/gallery/:id', ...trainerAuth, updateGalleryImage as any);
router.delete('/me/gallery/:id', ...trainerAuth, deleteGalleryImage as any);

// FAQ CRUD
router.post('/me/faq', ...trainerAuth, addFAQ as any);
router.put('/me/faq/:id', ...trainerAuth, updateFAQ as any);
router.delete('/me/faq/:id', ...trainerAuth, deleteFAQ as any);

export default router;
