import { Router } from 'express';
import { authenticate, trainerOnly } from '../middleware/auth';
import {
    createProgram,
    updateProgram,
    publishProgram,
    getProgramById,
    getTrainerPrograms,
    addWorkout,
    deleteProgram,
} from '../controllers/programController';

const router = Router();

// Public (with optional auth for trainer's own programs)
router.get('/trainers/:trainerId/programs', authenticate as any, getTrainerPrograms as any);
router.get('/:id', authenticate as any, getProgramById as any);

// Trainer only routes
router.post('/', authenticate as any, trainerOnly as any, createProgram as any);
router.put('/:id', authenticate as any, trainerOnly as any, updateProgram as any);
router.delete('/:id', authenticate as any, trainerOnly as any, deleteProgram as any);
router.post('/:id/publish', authenticate as any, trainerOnly as any, publishProgram as any);
router.post('/:id/workouts', authenticate as any, trainerOnly as any, addWorkout as any);

export default router;
