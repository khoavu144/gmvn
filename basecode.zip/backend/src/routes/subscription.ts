import { Router } from 'express';
import { authenticate } from '../middleware/auth';
import {
    createCheckout,
    confirmPayment,
    getMySubscriptions,
    cancelSubscription,
    stripeWebhook,
} from '../controllers/subscriptionController';

const router = Router();

router.post('/', authenticate as any, createCheckout as any);
router.post('/confirm-payment', authenticate as any, confirmPayment as any);
router.get('/me', authenticate as any, getMySubscriptions as any);
router.post('/:id/cancel', authenticate as any, cancelSubscription as any);
router.post('/webhook/stripe', stripeWebhook as any); // Public - Stripe calls this

export default router;
