import { Router } from 'express';
import { authenticate } from '../middleware/auth';
import { getConversations, getMessages, sendMessage } from '../controllers/messageController';

const router = Router();

router.get('/conversations', authenticate as any, getConversations as any);
router.get('/conversations/:partnerId', authenticate as any, getMessages as any);
router.post('/send', authenticate as any, sendMessage as any);

export default router;
