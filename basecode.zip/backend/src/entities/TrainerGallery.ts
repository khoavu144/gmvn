import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    CreateDateColumn,
    ManyToOne,
    JoinColumn,
} from 'typeorm';
import { User } from './User';

export type GalleryCategory = 'transformation' | 'training' | 'event' | 'facility';

@Entity('trainer_gallery')
export class TrainerGallery {
    @PrimaryGeneratedColumn('uuid')
    id!: string;

    @Column({ type: 'uuid' })
    trainer_id!: string;

    @ManyToOne(() => User)
    @JoinColumn({ name: 'trainer_id' })
    trainer!: User;

    @Column({ type: 'varchar', length: 500 })
    image_url!: string;

    @Column({ type: 'varchar', length: 255, nullable: true })
    image_title!: string | null;

    @Column({ type: 'text', nullable: true })
    image_description!: string | null;

    @Column({ type: 'varchar', length: 255, nullable: true })
    client_name!: string | null; // 'John Doe' or 'Anonymous'

    @Column({ type: 'boolean', default: false })
    is_before_after!: boolean; // true if before/after composite

    @Column({ type: 'varchar', length: 100, nullable: true })
    transformation_timeline!: string | null; // '3 months', '6 months'

    @Column({
        type: 'enum',
        enum: ['transformation', 'training', 'event', 'facility'],
        default: 'training',
    })
    category!: GalleryCategory;

    @Column({ type: 'int', default: 0 })
    order_number!: number;

    @CreateDateColumn()
    created_at!: Date;
}
