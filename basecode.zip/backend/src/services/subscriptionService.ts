import { AppDataSource } from '../config/database';
import { Subscription } from '../entities/Subscription';
import { Program } from '../entities/Program';
import Stripe from 'stripe';

const subRepo = AppDataSource.getRepository(Subscription);
const programRepo = AppDataSource.getRepository(Program);

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
    apiVersion: '2026-02-25.clover',
});

class SubscriptionService {
    async createCheckoutSession(userId: string, programId: string) {
        const program = await programRepo.findOneBy({ id: programId, is_published: true });
        if (!program) throw new Error('Program not found');
        if (!program.trainer_id) throw new Error('Invalid program');

        const amount = program.price_monthly
            ? Math.round(Number(program.price_monthly) * 100) // Convert VND to cents (for demo)
            : 50000; // Default 500,000 VND as 50000 (smallest unit for VND)

        const paymentIntent = await stripe.paymentIntents.create({
            amount,
            currency: 'vnd',
            metadata: {
                user_id: userId,
                program_id: programId,
                trainer_id: program.trainer_id,
            },
        });

        return {
            client_secret: paymentIntent.client_secret,
            payment_intent_id: paymentIntent.id,
            amount,
            currency: 'vnd',
            program: {
                id: program.id,
                name: program.name,
                price_monthly: program.price_monthly,
            },
        };
    }

    async confirmPayment(userId: string, paymentIntentId: string) {
        // Verify the payment intent with Stripe
        const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);

        if (paymentIntent.status !== 'succeeded') {
            throw new Error('Payment not completed');
        }

        const { program_id, trainer_id } = paymentIntent.metadata;
        const amount = paymentIntent.amount / 100;

        // Check if subscription already exists
        const existing = await subRepo.findOneBy({
            user_id: userId,
            program_id,
            status: 'active',
        });
        if (existing) throw new Error('Already subscribed to this program');

        const sub = subRepo.create({
            user_id: userId,
            trainer_id,
            program_id,
            subscription_type: 'monthly',
            price_paid: amount,
            stripe_payment_intent_id: paymentIntentId,
            status: 'active',
            started_at: new Date(),
            next_billing_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        });

        // Increment program client count
        await programRepo.increment({ id: program_id }, 'current_clients', 1);

        return subRepo.save(sub);
    }

    async getUserSubscriptions(userId: string) {
        return subRepo.find({
            where: { user_id: userId },
            relations: ['program', 'trainer'],
            order: { created_at: 'DESC' },
        });
    }

    async cancelSubscription(userId: string, subscriptionId: string) {
        const sub = await subRepo.findOneBy({ id: subscriptionId, user_id: userId });
        if (!sub) throw new Error('Subscription not found');
        if (sub.status === 'cancelled') throw new Error('Already cancelled');

        sub.status = 'cancelled';
        sub.ended_at = new Date();

        // Decrement program client count
        await programRepo.decrement({ id: sub.program_id }, 'current_clients', 1);

        return subRepo.save(sub);
    }

    async getTrainerStats(trainerId: string) {
        const activeCount = await subRepo.count({
            where: { trainer_id: trainerId, status: 'active' },
        });

        const allSubs = await subRepo.find({
            where: { trainer_id: trainerId, status: 'active' },
        });

        const monthlyRevenue = allSubs.reduce((sum, s) => {
            return sum + (Number(s.price_paid) || 0);
        }, 0);

        // Platform takes 20%, trainer gets 80%
        const trainerRevenue = monthlyRevenue * 0.8;

        return {
            active_clients: activeCount,
            monthly_revenue: trainerRevenue,
        };
    }
}

export const subscriptionService = new SubscriptionService();
