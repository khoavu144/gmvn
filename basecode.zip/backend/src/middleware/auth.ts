import { Request, Response, NextFunction } from 'express';
import { verifyAccessToken, TokenPayload } from '../utils/jwt';

// Extend Express Request to include user
declare global {
    namespace Express {
        interface Request {
            user?: TokenPayload;
        }
    }
}

export const authenticate = (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    const authHeader = req.headers.authorization;
    const token = authHeader?.split(' ')[1]; // Bearer {token}

    if (!token) {
        return res.status(401).json({ success: false, error: 'No token provided' });
    }

    try {
        const payload = verifyAccessToken(token);
        req.user = payload;
        next();
    } catch (error) {
        return res.status(401).json({ success: false, error: 'Invalid or expired token' });
    }
};

export const trainerOnly = (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    if (req.user?.user_type !== 'trainer') {
        return res.status(403).json({ success: false, error: 'Trainers only' });
    }
    next();
};

export const athleteOnly = (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    if (req.user?.user_type !== 'athlete') {
        return res.status(403).json({ success: false, error: 'Athletes only' });
    }
    next();
};
