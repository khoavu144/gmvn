import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { Provider } from 'react-redux';
import { QueryClientProvider, QueryClient } from '@tanstack/react-query';
import { store } from './store/store';

import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Trainers from './pages/Trainers';
import Profile from './pages/Profile';
import TrainerDetailPage from './pages/TrainerDetailPage';
import ProgramsPage from './pages/ProgramsPage';
import MessagesPage from './pages/MessagesPage';
import WorkoutsPage from './pages/WorkoutsPage';
import ProfilePublic from './pages/ProfilePublic';

const queryClient = new QueryClient();

const router = createBrowserRouter([
  { path: '/', element: <Home /> },
  { path: '/login', element: <Login /> },
  { path: '/register', element: <Register /> },
  { path: '/dashboard', element: <Dashboard /> },
  { path: '/trainers', element: <Trainers /> },
  { path: '/trainers/:trainerId', element: <TrainerDetailPage /> },
  { path: '/profile', element: <Profile /> },
  { path: '/programs', element: <ProgramsPage /> },
  { path: '/messages', element: <MessagesPage /> },
  { path: '/workouts', element: <WorkoutsPage /> },
  // Public trainer profile landing page (slug or trainerId)
  { path: '/trainer/:trainerId', element: <ProfilePublic /> },
]);

function App() {
  return (
    <Provider store={store}>
      <QueryClientProvider client={queryClient}>
        <RouterProvider router={router} />
      </QueryClientProvider>
    </Provider>
  );
}

export default App;
