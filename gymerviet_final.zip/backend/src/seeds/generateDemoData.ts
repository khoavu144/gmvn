/**
 * GYMERVIET - Generate Demo Data & Professional Admin
 * Tạo 8 profile chuyên nghiệp: 2 Coach + 2 Athlete + 2 Gym Owner + 2 Admin
 * Và thiết lập Admin cho: khoa.vnd92@gmail.com
 * Run: cd backend && npx ts-node src/seeds/generateDemoData.ts
 */

import 'reflect-metadata';
import { AppDataSource } from '../config/database';
import { User } from '../entities/User';
import bcrypt from 'bcryptjs';

const DEMO_PASSWORD = 'Demo@123456';
const ADMIN_EMAIL = 'khoa.vnd92@gmail.com';
const ADMIN_PASSWORD = 'Vndk849090@';

// ============================================================
// DEMO USERS DATA
// ============================================================

const demoUsers = [
    // COACHES
    {
        email: 'coach.hoang@demo.gymerviet.vn',
        full_name: 'Hoàng Minh Lê',
        user_type: 'trainer' as const,
        avatar_url: 'https://images.unsplash.com/photo-1541534741688-6078c64b52d3?q=80&w=260&h=260&auto=format&fit=crop',
        bio: 'Chuyên gia thể hình với 10 năm kinh nghiệm. Master of Sport, chuyên về đào tạo thi đấu và biến đổi vóc dáng.',
        specialties: ['Bodybuilding', 'Competition Prep', 'Nutritional Science'],
        base_price_monthly: 2500000,
        is_verified: true,
    },
    {
        email: 'coach.an@demo.gymerviet.vn',
        full_name: 'An Tuyết Nguyễn',
        user_type: 'trainer' as const,
        avatar_url: 'https://images.unsplash.com/photo-1518611012118-2969c6360207?q=80&w=260&h=260&auto=format&fit=crop',
        bio: 'HLV Yoga & Pilates chuyên sâu. Giúp học viên tìm lại sự cân bằng, linh hoạt và phục hồi sau chấn thương.',
        specialties: ['Yoga Flow', 'Pilates', 'Post-Injury Rehab'],
        base_price_monthly: 1800000,
        is_verified: true,
    },
    // ATHLETES
    {
        email: 'athlete.nam@demo.gymerviet.vn',
        full_name: 'Nam Văn Trần',
        user_type: 'athlete' as const,
        avatar_url: 'https://images.unsplash.com/photo-1550345332-09e3ac987658?q=80&w=260&h=260&auto=format&fit=crop',
        bio: 'Nhân viên văn phòng đam mê gym. Đang trong hành trình tăng cơ giảm mỡ để có vóc dáng đẹp hơn.',
        height_cm: 175,
        current_weight_kg: 82,
        experience_level: 'intermediate',
    },
    {
        email: 'athlete.ly@demo.gymerviet.vn',
        full_name: 'Ly Thị Mai',
        user_type: 'athlete' as const,
        avatar_url: 'https://images.unsplash.com/photo-1571731956672-f2b94d7db0cb?q=80&w=260&h=260&auto=format&fit=crop',
        bio: 'Người mẫu ảnh, tập luyện để duy trì chỉ số cơ thể hoàn hảo và sức khỏe dẻo dai.',
        height_cm: 168,
        current_weight_kg: 50,
        experience_level: 'beginner',
    },
    // GYM OWNERS
    {
        email: 'owner.thang@demo.gymerviet.vn',
        full_name: 'Thắng Nguyễn Văn',
        user_type: 'gym_owner' as const,
        gym_owner_status: 'approved' as const,
        avatar_url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=260&h=260&auto=format&fit=crop',
        bio: 'Chủ sở hữu chuỗi Iron Muscle Gym. Luôn tìm kiếm sự chuyên nghiệp trong quản lý và vận hành.',
    },
    {
        email: 'owner.phuong@demo.gymerviet.vn',
        full_name: 'Phương Thảo Lê',
        user_type: 'gym_owner' as const,
        gym_owner_status: 'approved' as const,
        avatar_url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=260&h=260&auto=format&fit=crop',
        bio: 'Nhà sáng lập Pure Yoga Center. Định hướng phát triển cộng đồng thể thao văn minh.',
    },
    // ADMINS
    {
        email: 'admin.manager@gymerviet.vn',
        full_name: 'Quản Lý Hệ Thống',
        user_type: 'admin' as const,
        avatar_url: 'https://images.dicebear.com/7.x/bottts/svg?seed=Manager',
        bio: 'Tài khoản điều hành và xử lý yêu cầu hệ thống.',
    },
    {
        email: 'admin.audit@gymerviet.vn',
        full_name: 'Kiểm Duyệt Viên',
        user_type: 'admin' as const,
        avatar_url: 'https://images.dicebear.com/7.x/bottts/svg?seed=Audit',
        bio: 'Kiểm duyệt hồ sơ HLV và các cơ sở phòng tập.',
    },
];

async function seed() {
    console.log('🚀 Cỡ động cơ GYMERVIET - Bắt đầu Seed dữ liệu...');

    try {
        await AppDataSource.initialize();
        console.log('✅ Đã kết nối Database.');

        const userRepo = AppDataSource.getRepository(User);

        // 1. Tạo mật khẩu hash
        const hashedDemoPwd = await bcrypt.hash(DEMO_PASSWORD, 10);
        const hashedAdminPwd = await bcrypt.hash(ADMIN_PASSWORD, 10);

        // 2. Tạo Admin chính chủ
        console.log(`\n👑 Đang tạo Admin chính: ${ADMIN_EMAIL}...`);
        let mainAdmin = await userRepo.findOneBy({ email: ADMIN_EMAIL });
        if (mainAdmin) {
            mainAdmin.password = hashedAdminPwd;
            mainAdmin.user_type = 'admin';
            mainAdmin.full_name = 'KHOA VN';
            await userRepo.save(mainAdmin);
            console.log('   ⚠️  Tài khoản đã tồn tại - Đã cập nhật mật khẩu và quyền Admin.');
        } else {
            mainAdmin = userRepo.create({
                email: ADMIN_EMAIL,
                password: hashedAdminPwd,
                full_name: 'KHOA VN',
                user_type: 'admin',
                is_verified: true,
                avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=KhoaVN'
            });
            await userRepo.save(mainAdmin);
            console.log('   ✅ Đã tạo mới tài khoản Admin.');
        }

        // 3. Tạo 8 demo users
        console.log('\n👥 Đang tạo 8 tài khoản demo chuyên nghiệp...');
        for (const userData of demoUsers) {
            const existing = await userRepo.findOneBy({ email: userData.email });
            if (existing) {
                console.log(`   ⏩ Bỏ qua ${userData.email} (Đã tồn tại).`);
                continue;
            }

            const newUser = userRepo.create({
                ...userData,
                password: hashedDemoPwd
            });
            await userRepo.save(newUser);
            console.log(`   ✅ Đã tạo [${userData.user_type}]: ${userData.full_name}`);
        }

        console.log('\n✨ QUÁ TRÌNH SEED HOÀN TẤT! ✨');
        console.log('-----------------------------------');
        console.log(`Admin Email: ${ADMIN_EMAIL}`);
        console.log(`Admin Password: ${ADMIN_PASSWORD}`);
        console.log(`Demo Users Password: ${DEMO_PASSWORD}`);
        console.log('-----------------------------------');

    } catch (error) {
        console.error('❌ Lỗi trong quá trình seed:', error);
    } finally {
        if (AppDataSource.isInitialized) {
            await AppDataSource.destroy();
        }
    }
}

seed();
