import { Link } from 'react-router-dom';

export default function Home() {
    return (
        <div className="bg-white overflow-hidden">
            {/* 1. HERO SECTION (Split Screen) */}
            <section className="border-b border-gray-200">
                <div className="grid md:grid-cols-2 min-h-[90vh]">

                    {/* LEFT: For Gymer / Trainer */}
                    <div className="relative bg-white px-8 py-24 md:px-16 md:py-32 flex flex-col justify-center animate-fade-in border-b md:border-b-0 md:border-r border-gray-200 group">
                        <div className="absolute inset-0 bg-gray-50 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"></div>
                        <div className="relative z-10 max-w-lg mx-auto md:mr-0 md:ml-auto w-full">
                            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gray-100 text-[10px] font-bold uppercase tracking-wider text-gray-500 mb-8 border border-gray-200">
                                <span className="w-1.5 h-1.5 rounded-full bg-black animate-pulse" />
                                Cho Cá Nhân
                            </div>
                            <h2 className="text-5xl md:text-6xl lg:text-7xl font-extrabold text-black leading-[1.05] mb-6 tracking-tight">
                                Tập Luyện.<br /> <span className="text-gray-400">Đột Phá.</span>
                            </h2>
                            <p className="text-lg text-gray-600 mb-10 leading-relaxed font-medium">
                                Nền tảng kết nối Gymer và Coach hàng đầu Việt Nam. Nhận giáo án cá nhân hóa, theo dõi tiến trình và tương tác trực tiếp 1-1.
                            </p>
                            <div className="flex flex-col sm:flex-row gap-4">
                                <Link to="/register" className="btn-primary px-8 py-4 text-sm whitespace-nowrap">
                                    Bắt đầu tập luyện
                                </Link>
                                <Link to="/trainers" className="btn-secondary px-8 py-4 text-sm whitespace-nowrap">
                                    Tìm Coach
                                </Link>
                            </div>
                        </div>
                    </div>

                    {/* RIGHT: For Gym Center */}
                    <div className="relative bg-black text-white px-8 py-24 md:px-16 md:py-32 flex flex-col justify-center animate-fade-in group">
                        <div className="absolute inset-0 bg-gray-900 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"></div>
                        <div className="relative z-10 max-w-lg mx-auto md:ml-0 md:mr-auto w-full">
                            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-[10px] font-bold uppercase tracking-wider text-gray-300 mb-8 border border-white/10">
                                <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                                Cho Doanh Nghiệp
                            </div>
                            <h2 className="text-5xl md:text-6xl lg:text-7xl font-extrabold text-white leading-[1.05] mb-6 tracking-tight">
                                Quản Lý.<br /><span className="text-gray-500">Tăng Trưởng.</span>
                            </h2>
                            <p className="text-lg text-gray-400 mb-10 leading-relaxed font-medium">
                                Số hóa phòng tập của bạn. Quản lý hội viên, Coach, chi nhánh và doanh thu tất cả trong một nền tảng chuyên nghiệp.
                            </p>
                            <div className="flex flex-col sm:flex-row gap-4">
                                <Link to="/gyms" className="bg-white text-black hover:bg-gray-200 transition-colors font-bold uppercase tracking-widest text-xs px-8 py-4 rounded-lg flex items-center justify-center whitespace-nowrap">
                                    Khám phá danh sách
                                </Link>
                                <Link to="/register" className="border-2 border-gray-700 hover:border-white text-white transition-colors font-bold uppercase tracking-widest text-xs px-8 py-4 rounded-lg flex items-center justify-center whitespace-nowrap">
                                    Trở thành Đối Tác
                                </Link>
                            </div>
                        </div>
                    </div>

                </div>
            </section>

            {/* 2. STATS SECTION (Trust Signals) */}
            <section className="bg-white py-12 md:py-20 border-b border-gray-100">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12">
                        {[
                            { label: 'Người tập luyện', value: '10,000+' },
                            { label: 'Coach', value: '500+' },
                            { label: 'Buổi tập đã xong', value: '50,000+' },
                            { label: 'Đánh giá trung bình', value: '4.9 ★' },
                        ].map((stat, i) => (
                            <div key={i} className="text-center">
                                <div className="text-3xl md:text-4xl font-extrabold text-black mb-1">{stat.value}</div>
                                <div className="text-xs text-gray-500 uppercase tracking-widest font-medium">{stat.label}</div>
                            </div>
                        ))}
                    </div>
                    <p className="text-center text-[10px] text-gray-300 mt-12 uppercase tracking-[0.2em]">
                        Hệ thống xác minh bởi cộng đồng Coach chuyên nghiệp VIỆT NAM
                    </p>
                </div>
            </section>

            {/* 3. HOW IT WORKS (3 Step Process) */}
            <section className="py-24 md:py-32 bg-gray-50/50">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-16 md:mb-24">
                    <p className="text-xs font-bold text-gray-400 uppercase tracking-[0.3em] mb-4">Quy trình</p>
                    <h2 className="text-3xl md:text-5xl font-extrabold text-black tracking-tight">Bắt đầu chỉ với 3 bước</h2>
                </div>
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="grid md:grid-cols-3 gap-12 md:gap-8 relative">
                        {/* Connector line (desktop only) */}
                        <div className="hidden md:block absolute top-10 left-[15%] right-[15%] h-px bg-gray-200 -z-10" />

                        {[
                            { step: '01', title: 'Tìm Coach', desc: 'Duyệt danh sách Coach theo chuyên môn, mục tiêu và mức giá mong muốn.' },
                            { step: '02', title: 'Kết nối trực tiếp', desc: 'Nhắn tin hỏi thăm, tư vấn và đặt lịch tập phù hợp với cá nhân bạn.' },
                            { step: '03', title: 'Tập luyện & Tiến bộ', desc: 'Thực hiện chương trình cá nhân hóa và theo dõi kết quả từng ngày qua biểu đồ.' },
                        ].map((item, i) => (
                            <div key={i} className="flex flex-col items-center group">
                                <div className="w-20 h-20 rounded-full bg-white border border-gray-200 flex items-center justify-center mb-8 shadow-sm group-hover:border-black transition-colors duration-300">
                                    <span className="text-xl font-extrabold text-black tracking-tighter">{item.step}</span>
                                </div>
                                <h3 className="text-xl font-bold text-black mb-4">{item.title}</h3>
                                <p className="text-gray-600 max-w-[280px] leading-relaxed text-sm">{item.desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* 4. WHY CHOOSE US (Features Cards) */}
            <section className="py-24 md:py-32 bg-white">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 gap-16 items-start">
                    <div className="sticky top-20">
                        <p className="text-xs font-bold text-gray-400 uppercase tracking-[0.3em] mb-4">Ưu điểm</p>
                        <h2 className="text-3xl md:text-5xl font-extrabold text-black tracking-tight mb-8">
                            Tại sao chọn chúng tôi?
                        </h2>
                        <p className="text-gray-600 text-lg leading-relaxed mb-8">
                            Chúng tôi loại bỏ các rào cản truyền thống giữa Coach và người tập, tạo ra môi trường làm việc trực tiếp, minh bạch và hiệu quả 100%.
                        </p>
                        <div className="flex gap-4">
                            <Link to="/about" className="text-black font-bold text-sm underline underline-offset-8 decoration-gray-200 hover:decoration-black transition-all">Tìm hiểu về triết lý của chúng tôi →</Link>
                        </div>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-6">
                        {[
                            {
                                title: 'Coach Xác minh',
                                icon: '✓',
                                desc: 'Tất cả Coach trên hệ thống đều phải trải qua bước kiểm duyệt chứng chỉ và kinh nghiệm thực tế.'
                            },
                            {
                                title: 'Dữ liệu cá nhân',
                                icon: '🔒',
                                desc: 'Dữ liệu sức khỏe và tiến trình của bạn được mã hóa và bảo mật hoàn toàn.'
                            },
                            {
                                title: 'Công cụ cho Coach',
                                icon: '⚙️',
                                desc: 'Hệ thống quản lý học viên chuyên nghiệp, giúp Coach tập trung 100% vào chuyên môn.'
                            },
                            {
                                title: 'Cộng đồng thật',
                                icon: '👥',
                                desc: 'Hàng nghìn người tập đã đạt được mục tiêu Body Transformation qua nền tảng.'
                            }
                        ].map((card, i) => (
                            <div key={i} className="card !p-8 group hover:-translate-y-1 bg-white">
                                <div className="text-2xl mb-6 w-12 h-12 rounded bg-gray-50 flex items-center justify-center group-hover:bg-black group-hover:text-white transition-colors">
                                    {card.icon}
                                </div>
                                <h4 className="text-lg font-bold text-black mb-3">{card.title}</h4>
                                <p className="text-sm text-gray-600 leading-relaxed">{card.desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* 5. FEATURED TRAINERS (Carousel Mock) */}
            <section className="py-24 md:py-32 bg-gray-50/30 overflow-hidden">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
                    <div className="flex justify-between items-end">
                        <div>
                            <p className="text-xs font-bold text-gray-400 uppercase tracking-[0.3em] mb-4">Danh sách</p>
                            <h2 className="text-3xl md:text-5xl font-extrabold text-black tracking-tight">Coach nổi bật</h2>
                        </div>
                        <div className="hidden sm:flex gap-2">
                            <button className="w-10 h-10 border border-gray-200 rounded-full flex items-center justify-center hover:border-black transition-colors">←</button>
                            <button className="w-10 h-10 border border-gray-200 rounded-full flex items-center justify-center hover:border-black transition-colors">→</button>
                        </div>
                    </div>
                </div>

                <div className="max-w-[100vw] overflow-x-auto no-scrollbar">
                    <div className="flex gap-6 px-4 sm:px-6 lg:px-8 pb-8 min-w-max ml-[calc((100vw-1280px)/2)] max-w-7xl">
                        {[
                            { name: 'Coach John', role: 'Strength Training', rating: '4.9', reviews: '250', clients: '200+' },
                            { name: 'Coach Jane', role: 'Yoga & Wellness', rating: '5.0', reviews: '120', clients: '150+' },
                            { name: 'Coach Mike', role: 'Weight Loss', rating: '4.8', reviews: '98', clients: '180+' },
                            { name: 'Coach Sarah', role: 'Powerlifting', rating: '4.9', reviews: '145', clients: '110+' },
                            { name: 'Coach Alex', role: 'Mobility & Rehab', rating: '4.7', reviews: '82', clients: '90+' },
                        ].map((coach, i) => (
                            <div key={i} className="w-[280px] card !p-6 group hover:border-black transition-all">
                                <div className="w-full aspect-square bg-gray-100 rounded-xs mb-6 overflow-hidden relative">
                                    <div className="absolute inset-0 flex items-center justify-center text-3xl opacity-20">🏋️</div>
                                </div>
                                <h4 className="text-lg font-bold text-black mb-1">{coach.name}</h4>
                                <p className="text-xs text-gray-500 uppercase tracking-widest font-medium mb-4">{coach.role}</p>
                                <div className="flex items-center gap-3 mb-6">
                                    <div className="flex items-center text-xs font-bold text-black bg-gray-100 px-2 py-0.5 rounded-full">★ {coach.rating}</div>
                                    <div className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">{coach.reviews} đánh giá</div>
                                </div>
                                <div className="flex justify-between items-center pt-5 border-t border-gray-100">
                                    <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{coach.clients} học viên</span>
                                    <Link to="/trainers" className="text-xs font-bold text-black hover:underline underline-offset-4">Xem Profile →</Link>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* 6. TESTIMONIALS (Social Proof) */}
            <section className="py-24 md:py-32 bg-white border-y border-gray-100">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-16 md:mb-24">
                        <p className="text-xs font-bold text-gray-400 uppercase tracking-[0.3em] mb-4">Cảm nhận</p>
                        <h2 className="text-3xl md:text-5xl font-extrabold text-black tracking-tight">Thành công từ cộng đồng</h2>
                    </div>

                    <div className="grid md:grid-cols-3 gap-8">
                        {[
                            {
                                quote: 'Tôi đã giảm 15kg trong 3 tháng nhờ sự tận tâm của Coach. Hệ thống theo dõi rất dễ dùng.',
                                author: 'Nguyễn Minh',
                                location: 'TP. Hồ Chí Minh',
                                rating: 5
                            },
                            {
                                quote: 'Hệ thống chat trực tiếp rất tiện lợi. Tôi luôn nhận được phản hồi nhanh chóng mỗi khi có thắc mắc.',
                                author: 'Trần Hương',
                                location: 'Hà Nội',
                                rating: 5
                            },
                            {
                                quote: 'Từng là vận động viên chuyên nghiệp, GYMERVIET giúp tôi quay trở lại tập luyện với lộ trình bài bản nhất.',
                                author: 'Phạm Linh',
                                location: 'Đà Nẵng',
                                rating: 5
                            }
                        ].map((t, i) => (
                            <div key={i} className="p-8 md:p-10 border border-gray-100 rounded-xs bg-gray-50/50 flex flex-col justify-between">
                                <div>
                                    <div className="flex gap-0.5 mb-6">
                                        {[...Array(t.rating)].map((_, j) => <span key={j} className="text-sm">★</span>)}
                                    </div>
                                    <p className="text-lg text-black font-medium leading-relaxed italic">"{t.quote}"</p>
                                </div>
                                <div className="mt-10 flex items-center gap-4">
                                    <div className="w-10 h-10 rounded-full bg-gray-200 flex-shrink-0" />
                                    <div>
                                        <div className="text-sm font-bold text-black">{t.author}</div>
                                        <div className="text-[10px] text-gray-400 uppercase tracking-widest font-bold">{t.location}</div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* 7. ROLES INTRODUCTION (Athlete / Coach / GymCenter) */}
            <section className="py-24 md:py-32 bg-white">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16 md:mb-24">
                    <p className="text-xs font-bold text-gray-400 uppercase tracking-[0.3em] mb-4 text-center">Nền Tảng Đa Chiều</p>
                    <h2 className="text-3xl md:text-5xl font-extrabold text-black tracking-tight text-center">Hệ sinh thái dành riêng cho bạn</h2>
                </div>

                <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="grid md:grid-cols-3 gap-6">
                        {[
                            {
                                title: 'Athlete',
                                subtitle: 'Người tập luyện',
                                desc: 'Tìm kiếm lộ trình tập luyện bài bản, theo dõi tiến độ và kết nối trực tiếp với Coach để đạt hiệu quả tối đa.',
                                cta: 'Bắt đầu tập luyện',
                                link: '/register',
                                bg: 'bg-gray-50'
                            },
                            {
                                title: 'Coach',
                                subtitle: 'Huấn luyện viên',
                                desc: 'Xây dựng thương hiệu cá nhân, quản lý hàng trăm học viên dễ dàng và tối ưu hóa doanh thu từ nghề PT.',
                                cta: 'Đăng ký Coach',
                                link: '/register?role=trainer',
                                bg: 'bg-black text-white'
                            },
                            {
                                title: 'Gym Center',
                                subtitle: 'Cơ sở / Phòng tập',
                                desc: 'Số hóa quản lý chi nhánh, thiết bị, thu hút học viên mới và quản trị quan hệ đối tác với các Coach chuyên nghiệp.',
                                cta: 'Trở thành Đối Tác',
                                link: '/gym-owner/register',
                                bg: 'bg-gray-50'
                            }
                        ].map((role, i) => (
                            <div key={i} className={`p-8 md:p-10 rounded-xl flex flex-col h-full ${role.bg}`}>
                                <h3 className="text-3xl font-extrabold mb-1">{role.title}</h3>
                                <p className={`text-xs font-bold uppercase tracking-widest mb-6 ${role.bg.includes('bg-black') ? 'text-gray-400' : 'text-gray-500'}`}>{role.subtitle}</p>
                                <p className={`text-sm leading-relaxed mb-10 flex-1 ${role.bg.includes('bg-black') ? 'text-gray-300' : 'text-gray-600'}`}>{role.desc}</p>
                                <Link
                                    to={role.link}
                                    className={`w-full text-center py-4 rounded-xs text-xs font-bold uppercase tracking-widest transition-all ${role.bg.includes('bg-black')
                                        ? 'bg-white text-black hover:bg-gray-200'
                                        : 'bg-black text-white hover:bg-gray-800'
                                        }`}
                                >
                                    {role.cta}
                                </Link>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* 8. FAQ SECTION (Accordion) */}
            <section className="py-24 md:py-32 bg-gray-50/50">
                <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-16">
                        <p className="text-xs font-bold text-gray-400 uppercase tracking-[0.3em] mb-4">Hỗ trợ</p>
                        <h2 className="text-3xl md:text-5xl font-extrabold text-black tracking-tight">Câu hỏi thường gặp</h2>
                    </div>

                    <div className="space-y-4">
                        {[
                            {
                                q: 'GYMERVIET hoạt động như thế nào?',
                                a: 'Chúng tôi là nền tảng kết nối trực tiếp. Bạn tìm Coach phù hợp, nhắn tin trao đổi, và đăng ký gói tập. Mọi quy trình theo dõi buổi tập và tiến độ đều được thực hiện ngay trên web app.'
                            },
                            {
                                q: 'Tôi có thể thay đổi Coach sau khi đăng ký không?',
                                a: 'Có, bạn có thể yêu cầu đổi Coach trong vòng 7 ngày đầu tiên nếu cảm thấy không phù hợp. Chúng tôi sẽ hỗ trợ chuyển đổi hoặc hoàn phí theo chính sách.'
                            },
                            {
                                q: 'Dữ liệu sức khỏe của tôi có an toàn không?',
                                a: 'An toàn tuyệt đối. Mọi thông tin sức khỏe và lộ trình tập luyện chỉ có bạn và Coach trực tiếp của bạn được quyền truy cập.'
                            }
                        ].map((faq, i) => (
                            <details key={i} className="group border border-gray-200 bg-white rounded-xs">
                                <summary className="flex justify-between items-center p-6 cursor-pointer list-none focus:outline-none">
                                    <span className="text-sm md:text-base font-bold text-black">{faq.q}</span>
                                    <span className="text-gray-400 font-mono transition-transform group-open:rotate-45">+</span>
                                </summary>
                                <div className="px-6 pb-6 text-sm text-gray-600 leading-relaxed border-t border-gray-50 pt-4">
                                    {faq.a}
                                </div>
                            </details>
                        ))}
                    </div>

                    <div className="mt-12 text-center">
                        <Link to="/faq" className="text-xs font-bold text-gray-400 hover:text-black uppercase tracking-widest underline underline-offset-4">Xem tất cả câu hỏi →</Link>
                    </div>
                </div>
            </section>

            {/* 9. FINAL CTA SECTION (Final Push) */}
            <section className="py-24 md:py-40 bg-black text-white text-center">
                <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
                    <h2 className="text-4xl md:text-6xl font-extrabold mb-8 tracking-tighter leading-none">
                        Sẵn sàng để thay đổi cơ thể của bạn?
                    </h2>
                    <p className="text-lg text-gray-400 mb-12 max-w-xl mx-auto">
                        Tham gia cùng 999+ gymer khác đang tập luyện hiệu quả hơn mỗi ngày cùng đội ngũ Coach chuyên nghiệp.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                        <Link to="/register" className="bg-white text-black px-10 py-5 rounded-xs text-sm font-bold uppercase tracking-widest hover:bg-gray-100 transition-colors">
                            Bắt đầu miễn phí ngay
                        </Link>
                        <Link to="/trainers" className="border border-white/20 text-white px-10 py-5 rounded-xs text-sm font-bold uppercase tracking-widest hover:bg-white/10 transition-colors">
                            Khám phá Coach
                        </Link>
                    </div>
                    <p className="mt-10 text-[10px] text-gray-500 uppercase tracking-[0.2em] font-medium">
                        Không cần thẻ tín dụng • Hoàn toàn miễn phí khởi tạo
                    </p>
                </div>
            </section>
        </div>
    );
}



