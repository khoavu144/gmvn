import React, { useEffect, useState } from 'react';
import { gymService } from '../services/gymService';
import { trainerService } from '../services/trainerService';
import type { GymBranch, GymTrainerLink, User } from '../types';
import { useToast } from './Toast';

interface GymTrainerManagerProps {
    branches: GymBranch[];
}

const GymTrainerManager: React.FC<GymTrainerManagerProps> = ({ branches }) => {
    const { toast, ToastComponent } = useToast();
    const [activeBranchId, setActiveBranchId] = useState<string>(branches[0]?.id || '');
    const [links, setLinks] = useState<GymTrainerLink[]>([]);
    const [loading, setLoading] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState<User[]>([]);
    const [searching, setSearching] = useState(false);

    useEffect(() => {
        if (activeBranchId) fetchLinks();
    }, [activeBranchId]);

    const fetchLinks = async () => {
        try {
            setLoading(true);
            // We reuse public gym trainers list for now
            // But we might need a richer owner-only endpoint eventually
            const res = await gymService.getGymTrainers(activeBranchId);
            if (res.success) {
                setLinks(res.trainers || []);
            }
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const handleSearch = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!searchQuery.trim()) return;
        try {
            setSearching(true);
            const res = await trainerService.searchTrainers({ search: searchQuery });
            if (res.success) {
                setSearchResults(res.trainers || []);
            }
        } catch (error) {
            toast.error('Lỗi khi tìm kiếm Coach');
        } finally {
            setSearching(false);
        }
    };

    const handleInvite = async (trainerId: string) => {
        try {
            const role = window.prompt('Vị trí đảm nhận tại Gym? (vd: Senior PT, Yoga Instructor)', 'Professional Coach');
            if (role === null) return;

            const res = await gymService.inviteTrainer(activeBranchId, {
                trainer_id: trainerId,
                role_at_gym: role
            });

            if (res.success) {
                toast.success('Đã gửi lời mời hợp tác!');
                setSearchResults([]);
                setSearchQuery('');
                fetchLinks();
            } else {
                toast.error(res.error || 'Không thể gửi lời mời');
            }
        } catch (error) {
            toast.error('Lỗi kết nối server');
        }
    };

    const handleRemove = async (linkId: string) => {
        if (!window.confirm('Ngừng hợp tác với Coach này?')) return;
        try {
            const res = await gymService.removeTrainer(activeBranchId, linkId);
            if (res.success) {
                toast.success('Đã ngừng hợp tác');
                fetchLinks();
            }
        } catch (error) {
            toast.error('Lỗi khi thực hiện');
        }
    };

    return (
        <div className="space-y-8 animate-fade-in">
            {ToastComponent}
            <div>
                <h1 className="text-3xl font-black uppercase tracking-tight mb-2">Quản lý Coach</h1>
                <p className="text-gray-500">Mời và quản lý đội ngũ Coach tại các chi nhánh</p>
            </div>

            <div className="flex gap-4 overflow-x-auto pb-2 border-b border-gray-100">
                {branches.map(b => (
                    <button
                        key={b.id}
                        onClick={() => setActiveBranchId(b.id)}
                        className={`whitespace-nowrap px-4 py-2 font-bold text-xs uppercase tracking-widest transition-colors border-b-2 ${activeBranchId === b.id ? 'border-black text-black' : 'border-transparent text-gray-400'}`}
                    >
                        {b.branch_name}
                    </button>
                ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                {/* Current Trainers */}
                <div className="lg:col-span-2 space-y-4">
                    <h3 className="font-black uppercase tracking-tight text-lg mb-6">Đội ngũ hiện tại</h3>
                    {loading ? (
                        <div className="animate-pulse h-32 bg-gray-50 rounded-xl"></div>
                    ) : links.length === 0 ? (
                        <div className="bg-gray-50 border-2 border-dashed border-gray-100 rounded-xl p-12 text-center text-gray-400 italic">
                            Chưa có Coach nào liên kết với chi nhánh này.
                        </div>
                    ) : (
                        <div className="grid gap-4">
                            {links.map(link => (
                                <div key={link.id} className="card flex justify-between items-center bg-white border-2 border-black shadow-[4px_4px_0_0_black]">
                                    <div className="flex items-center gap-4">
                                        <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center overflow-hidden">
                                            {link.trainer?.avatar_url ? (
                                                <img src={link.trainer.avatar_url} className="w-full h-full object-cover" alt="" />
                                            ) : (
                                                <span className="font-bold text-gray-400">PT</span>
                                            )}
                                        </div>
                                        <div>
                                            <h4 className="font-bold text-sm">{link.trainer?.full_name}</h4>
                                            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">{link.role_at_gym || 'Coach'}</p>
                                            <span className={`text-[8px] font-black uppercase px-1 py-0.5 rounded ${link.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                                                {link.status === 'active' ? 'Đang hoạt động' : 'Chờ xác nhận'}
                                            </span>
                                        </div>
                                    </div>
                                    <button
                                        onClick={() => handleRemove(link.id)}
                                        className="text-xs font-bold text-red-500 hover:underline uppercase tracking-widest"
                                    >
                                        Ngừng hợp tác
                                    </button>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Invite UI */}
                <div className="lg:col-span-1">
                    <div className="bg-gray-50 p-6 rounded-xl border border-gray-200 sticky top-24">
                        <h3 className="font-black uppercase tracking-tight text-sm mb-6">Mời Coach mới</h3>
                        <form onSubmit={handleSearch} className="mb-6">
                            <div className="flex gap-2">
                                <input
                                    type="text"
                                    placeholder="Tên hoặc Email..."
                                    className="form-input text-sm flex-1"
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                />
                                <button type="submit" className="bg-black text-white px-4 rounded-xs text-xs font-bold uppercase tracking-widest hover:bg-zinc-800 transition-colors">
                                    Tìm
                                </button>
                            </div>
                        </form>

                        <div className="space-y-3">
                            {searching ? (
                                <div className="text-xs text-center text-gray-400 animate-pulse">Đang tìm...</div>
                            ) : searchResults.length > 0 ? (
                                searchResults.map(t => (
                                    <div key={t.id} className="flex items-center justify-between p-3 bg-white border border-gray-200 rounded-lg group">
                                        <div className="flex items-center gap-3">
                                            <div className="w-8 h-8 rounded-full bg-gray-100"></div>
                                            <div>
                                                <p className="text-xs font-bold">{t.full_name}</p>
                                                <p className="text-[10px] text-gray-400 truncate max-w-[120px]">{t.email}</p>
                                            </div>
                                        </div>
                                        <button
                                            onClick={() => handleInvite(t.id)}
                                            className="bg-black text-white p-2 rounded-xs opacity-0 shadow-sm group-hover:opacity-100 transition-opacity"
                                        >
                                            <span className="text-[10px] font-bold uppercase tracking-tighter">Mời</span>
                                        </button>
                                    </div>
                                ))
                            ) : searchQuery && (
                                <div className="text-xs text-center text-gray-400">Không tìm thấy coach phù hợp.</div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default GymTrainerManager;
